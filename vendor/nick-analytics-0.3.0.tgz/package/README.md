# Lean Analytics

Shared event tracking for Nick's blog, Magic Genie, and EventMap. A small TypeScript
core, optional framework adapters, D1/Postgres stores and reports, and read-only MCP tools.
The library is local and private; it has not been published to npm or deployed.

## Install locally

In this repository, run `npm ci` and `npm run build`. Then in a consuming project:

```sh
bun add @nick/analytics@file:../lean-analytics
```

For reproducible application builds, commit the tarball from `npm pack` under
`vendor/` and depend on `file:vendor/nick-analytics-0.3.0.tgz`. Frameworks remain in the app; install optional peers only for the
adapters you import. D1 consumers need `@cloudflare/workers-types`; MCP consumers
need `@modelcontextprotocol/sdk` (tested with 1.30.0).

## Import only the part you use

| Entry point | Purpose |
| --- | --- |
| `@nick/analytics` | Event types, JSON properties, `Transport`, `EventSink`, URL helpers, event factory |
| `/browser` | `createBrowserTracker` with page, track, identify, reset, context, flush |
| `/transport` | JSON delivery adapter for existing application acknowledgements |
| `/sqlite-reports` | Shared report SQL over a canonical SQLite/D1 view |
| `/report-api` | Authenticated Fetch report handler; app owns authorization |
| `/server` | Awaited server tracking; authenticated HTTP transport |
| `/http` | Native Request → Response collector, HTTP transport, bearer verification |
| `/adapters` | Framework-independent `Transport`, `EventSink`, `Reports`, and `AnalyticsStore` types |
| `/postgres` | Driver-independent PostgreSQL writes and shared reports |
| `/protocol` | Canonical wire validator; `/schemas/*` provides versioned JSON Schema |
| `/d1` | Binding adapter, migrations, stats, pages, ordered funnels, flows, journeys |
| `/react` | `usePageTracking(tracker, path)` for any router |
| `/react-router` | Blog's React Router component |
| `/tanstack` | EventMap's TanStack Router component |
| `/next/client` | Next navigation component, including its Suspense boundary |
| `/next/server` | Lazy App Router POST/OPTIONS handlers |
| `/mcp` | Authenticated, stateless Streamable HTTP reports using the official SDK |

## Browser

```ts
import { createBrowserTracker } from '@nick/analytics/browser';
const analytics = createBrowserTracker({
  siteId: 'blog', endpoint: 'https://YOUR-COLLECTOR/collect/blog',
});
await analytics.page();
await analytics.track('newsletter_signup_started', { placement: 'article-footer' });
const context = analytics.context(); // Include alongside the app's signup request.
```

Use either explicit `page()` calls or one router adapter. The package does not
monkey-patch browser history. React effects handle navigation and deduplicate
StrictMode replay. `track` returns `sent`, `skipped`, or `failed`; it does not throw
network errors into the app. `flush()` waits for already-sent requests; it is not a
durable offline queue. Event delivery can still be blocked by the browser/network.

IDs use random UUIDs. Visitors persist in local storage; sessions are tab-local and
expire after 30 minutes without an analytics context/event. `reset()` rotates both
IDs and removes the identified user. Storage failures fall back to memory. No IDs
are created on import or SSR. DNT/GPC and localhost/admin/API exclusions apply by
default; the app can explicitly configure its policy. A custom `enabled` function
can read the app's consent state. Call `page()` after consent is granted if the
current route was previously skipped.

Path reports omit query strings by default. UTM fields are copied into event
properties; `queryKeys` allows meaningful route parameters. Referrers omit queries,
fragments, and URL credentials. Properties are app-controlled JSON, not automatic
form/DOM capture. `identify(userId)` is a browser hint: public collectors discard it;
authenticated in-app collectors use `resolveUserId(request)` instead.

## Confirm conversions on the server

```ts
import { createServerTracker, createServerTransport } from '@nick/analytics/server';
const analytics = createServerTracker({
  siteId: 'blog',
  transport: createServerTransport({ endpoint: collectorURL, token: serverSecret }),
});
// After a new signup is persisted; context comes from the initiating browser.
await analytics.track('signup_completed', { ...context, userId, path: '/signup/complete' },
  {}, { id: `signup:${signupId}` });
```

Reuse the stable ID on webhook/operation retries. The store deduplicates `(siteId,source,id)`.
Browser IDs cannot occupy server event IDs. Public collection rejects `signup_completed` and `purchase_completed` by default;
configure other server-only names for the app's confirmed operations. User identity
comes from app auth; never use analytics visitor/session IDs as authentication.
If browser context is missing, omit visitor/session IDs. Trusted server events are
still counted by `eventCounts()`, while unattributed events cannot enter visitor or
session funnels. Public browser collection requires both IDs. Durable delivery/retries
belong in the app's existing outbox when the business event requires them.

## D1 and framework handlers

Apply `migrations/0001_events.sql` to a dedicated analytics D1 database. The tables
are separate from either application's legacy analytics schema.

```ts
import { createCollector } from '@nick/analytics/http';
import { createD1Store } from '@nick/analytics/d1';
const handler = createCollector({
  siteId: 'blog', sink: createD1Store(env.DB), allowedOrigins: ['https://your-blog.example'],
});
return handler(request);
```

Next: `createNextRoute(async request => options)` returns `POST` and `OPTIONS`.
Resolve OpenNext bindings inside that callback. TanStack Start:
`server: { handlers: { POST: ({ request }) => handler(request) } }`.
Hono: `app.all('/collect', c => handler(c.req.raw))`. No framework is imported by
the collector. For remote Next hosting, send to the shared Worker through
`createServerTransport`; D1 bindings are available inside Cloudflare, not ordinary Node. For a backend already
holding a store, use `createStoreTransport(store)` from `/server` to avoid an HTTP hop.

## Reports and definitions

```ts
const reports = createD1Store(env.DB);
const range = { siteId: 'blog', from: startMs, to: endMs };
await reports.stats(range);
await reports.pages(range);
await reports.eventCounts(range);
await reports.flows(range);
await reports.journey({ ...range, sessionId });
await reports.funnel({ ...range, windowMs: 7 * 86400000,
  steps: [{ name: 'page_view' }, { name: 'signup_completed', source: 'server' }],
});
```

All times are Unix milliseconds. Range ends are exclusive. Stats count distinct
visitor/session IDs on page events; they are measured browsers, not proven people.
Funnel steps count distinct subjects completing each prefix in order. Entries are
events matching step one in `[from,to)`; later steps may occur after `to`, within
`windowMs`. A repeated later attempt can succeed even when the first one failed.
`conversionRate` is last-step count / first-step count, between 0 and 1; an empty
cohort returns zero. `pending` counts subjects without a fully observed window,
including any that have already converted. Use a mature cohort for final rates.

Funnels default to visitors across sessions; `subject: 'session'` confines them to
sessions. Paths match exactly; use `name: 'page_view'` for all landing pages. Page
flows count adjacent page events within each session and requested range. Session
journeys default to 200 rows; the limit can be raised to 1000. Equal timestamps use
ingestion order; true order cannot be recovered when equal-time events arrive reversed.
Basic detected bots are excluded. Reporting never joins identities across sites.

## Other backends and databases

Pass a storage adapter to the collector and a report adapter to HTTP/MCP. The
Postgres adapter accepts your application's query function; it imports no database
driver. SQLite and Postgres use the same report semantics and conformance suite.
See [adapter architecture and examples](docs/ADAPTERS.md).

Rust and other languages interoperate through [JSON protocol v1](docs/PROTOCOL.md).
The package includes generated JSON Schema and a compiled Rust Serde example.
A complete Rust collector or native Rust database/reporting library is not included.

## Shared Worker and MCP

See `examples/worker/`. Configure origins (including the blog's actual domain),
create the D1 database, apply migrations, and set per-site server write tokens plus
a separate read token. `npm run worker:types` generates bindings from Wrangler.
The example includes a per-site/IP ingestion limiter and authenticated `/mcp`.
It does not require a VM, Postgres, a Durable Object, or an LLM.

MCP exposes `list_sites`, `get_stats`, `top_pages`, `run_funnel`, `page_flows`, and
`session_journey`, and `event_counts`. Supply the read credential as a bearer header in a client that
supports it. `authorize(request)` determines accessible sites before creating the
per-request SDK server. The adapter checks every report request against that list.

Retention is app-controlled; this library does not silently delete historical data.
Choose a retention/export policy before production. D1 storage, rows read/written,
and Worker CPU/request volume determine cost. Report windows are bounded; benchmark
large cohorts and add rollups/archives if observed usage requires them.

## Application adoption

Magic Genie and EventMap now consume the same versioned package artifact, with
app-owned adapters for their existing schemas and event vocabularies. Their browser
trackers, canonical validation, and shared reports use this package. Historical
rows remain in place; no second collector or copied library implementation is needed.

See [adoption and acceptance checks](docs/ADOPTION.md) for tested behavior, rollout
commands, and remaining limitations. Code integration is separate from production
deployment. The example standalone Worker remains an optional deployment pattern.

## Development

```sh
npm ci
npm run check
npm run worker:types
npm run check:examples
npm run worker:dry-run
npm run check:consumers
npm pack
```

Tests run real D1 SQL under Miniflare/workerd, browser storage and lifecycle tests,
HTTP trust/delivery checks, React navigation, and the actual MCP wire protocol.
Local runtime tests need permission to open loopback sockets.
See [extracted learnings](docs/LEARNINGS.md) for the source decisions and boundaries.
