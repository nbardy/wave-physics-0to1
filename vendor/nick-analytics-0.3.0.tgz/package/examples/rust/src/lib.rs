//! Canonical analytics JSON types for a Rust application.
//! This models the wire format; collector authentication, schema validation,
//! timestamps, URL sanitation and durable storage belong to the hosting server.
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum EventKind {
    Page,
    Event,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AnalyticsEvent {
    pub v: u8,
    pub id: String,
    pub site_id: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub visitor_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub session_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub user_id: Option<String>,
    pub name: String,
    pub kind: EventKind,
    pub timestamp: u64,
    pub path: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub referrer: Option<String>,
    #[serde(default)]
    pub properties: Map<String, Value>,
}

#[cfg(test)]
mod tests {
    use super::*;
    const BROWSER: &str = include_str!("../../protocol/browser-v1.json");
    const SERVER: &str = include_str!("../../protocol/server-v1.json");

    #[test]
    fn shares_the_typescript_browser_and_server_fixtures() {
        for input in [BROWSER, SERVER] {
            let event: AnalyticsEvent = serde_json::from_str(input).unwrap();
            assert_eq!(
                serde_json::to_value(event).unwrap(),
                serde_json::from_str::<Value>(input).unwrap()
            );
        }
    }

    #[test]
    fn preserves_missing_attribution_and_ignores_untrusted_storage_metadata() {
        let mut value: Value = serde_json::from_str(SERVER).unwrap();
        value["source"] = Value::String("server".into());
        value["bot"] = Value::Bool(false);
        let event: AnalyticsEvent = serde_json::from_value(value).unwrap();
        assert!(event.visitor_id.is_none() && event.session_id.is_none());
        let output = serde_json::to_value(event).unwrap();
        assert!(output.get("source").is_none() && output.get("bot").is_none());
    }
}
