//! Round-trip a canonical event on stdin; useful for cross-language contract checks.
use lean_analytics_protocol_example::AnalyticsEvent;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let event: AnalyticsEvent = serde_json::from_reader(std::io::stdin())?;
    serde_json::to_writer(std::io::stdout(), &event)?;
    Ok(())
}
