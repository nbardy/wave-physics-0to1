import { createServerTracker, createServerTransport } from '@nick/analytics/server';
import type { TrackingContext } from '@nick/analytics';

/** Construct using app-owned environment variables or Worker secret bindings. */
export function signupReporter(siteId: string, endpoint: string, token: string) {
  const server = createServerTracker({ siteId, transport: createServerTransport({ endpoint, token }) });
  return async (context: TrackingContext, userId: string, signupId: string) => {
    // Only call after the application has persisted the signup. Reuse signupId on retry.
    await server.track('signup_completed', { ...context, userId, path: '/signup/complete' }, {}, { id: `signup:${signupId}` });
  };
}
