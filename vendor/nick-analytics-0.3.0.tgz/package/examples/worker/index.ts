import { createCollector, verifyBearer } from '@nick/analytics/http';
import { createD1Store } from '@nick/analytics/d1';
import { createAnalyticsMcp } from '@nick/analytics/mcp';

// Env is generated from wrangler.jsonc by `npm run worker:types`.
export default {
  async fetch(request, env): Promise<Response> {
    const path = new URL(request.url).pathname;
    const sites: Record<string, readonly string[]> = env.SITES;
    const store = createD1Store(env.DB);
    if (path === '/mcp') {
      return createAnalyticsMcp({ reports: store, authorize: async req =>
        await verifyBearer(req, env.READ_TOKEN) ? Object.keys(sites) : null })(request);
    }
    const siteId = /^\/collect\/([a-zA-Z0-9_-]+)$/.exec(path)?.[1];
    if (!siteId || !sites[siteId]) return new Response('Not found', { status: 404 });
    const tokens: Record<string, string> = JSON.parse(env.SERVER_TOKENS ?? '{}');
    return createCollector({ siteId, sink: store, allowedOrigins: sites[siteId],
      authenticateServer: req => verifyBearer(req, tokens[siteId]),
      rateLimit: async req => (await env.INGEST_LIMITER.limit({ key: `${siteId}:${req.headers.get('CF-Connecting-IP') ?? 'unknown'}` })).success,
      onError: error => console.error('analytics_write_failed', error instanceof Error ? error.message : 'Unknown error'),
    })(request);
  },
} satisfies ExportedHandler<Env>;
