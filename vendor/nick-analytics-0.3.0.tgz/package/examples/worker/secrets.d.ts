// Secret names are configured via Wrangler and do not live in wrangler.jsonc.
interface Env { READ_TOKEN: string; SERVER_TOKENS: string }
