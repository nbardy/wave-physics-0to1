import { createD1Store } from '@nick/analytics/d1';
import { createNextRoute } from '@nick/analytics/next/server';
import type { D1Database } from '@cloudflare/workers-types';

/** Alternative to the shared collector: supply a dedicated D1 binding inside OpenNext. */
export function nextRoute(getDB: () => D1Database | Promise<D1Database>, getUserId: (request: Request) => Promise<string | undefined>) {
  return createNextRoute(async () => ({
    siteId: 'magicgenie', allowedOrigins: ['https://magicgenie.ai', 'https://www.magicgenie.ai'],
    sink: createD1Store(await getDB()), resolveUserId: getUserId,
  }));
}
// In an app/api/.../route.ts, export { POST, OPTIONS } from the configured result.
// Keep getCloudflareContext() / Clerk imports in the app; the library needs neither.
