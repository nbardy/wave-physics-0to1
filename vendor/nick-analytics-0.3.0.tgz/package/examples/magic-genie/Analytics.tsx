'use client';
import { createBrowserTracker } from '@nick/analytics/browser';
import { NextAnalytics } from '@nick/analytics/next/client';

export const analytics = createBrowserTracker({
  siteId: 'magicgenie', endpoint: 'http://localhost:8787/collect/magicgenie',
  legacyVisitorKey: 'mg_anonymous_id',
});
/** Mount once in app/layout.tsx as a client component. Configure the collector URL. */
export function Analytics() { return <NextAnalytics tracker={analytics} />; }

// Keep app vocabulary: analytics.track('pricing_cta_clicked', { plan: 'starter' }).
