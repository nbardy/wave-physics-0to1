import { createBrowserTracker } from '@nick/analytics/browser';
import { ReactRouterAnalytics } from '@nick/analytics/react-router';

export const analytics = createBrowserTracker({
  siteId: 'blog', endpoint: 'http://localhost:8787/collect/blog', allowLocalhost: true,
});

/** Mount once inside the existing BrowserRouter in src/main.tsx. */
export function Analytics() { return <ReactRouterAnalytics tracker={analytics} />; }

// Named interactions:
// void analytics.track('newsletter_signup_started', { placement: 'lesson-footer' });
// Include analytics.context() in the newsletter request. Its Worker confirms completion.
