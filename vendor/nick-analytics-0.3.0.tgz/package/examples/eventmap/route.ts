import { createCollector, type CollectorOptions } from '@nick/analytics/http';

/** Plug the result into createFileRoute('/api/analytics/...')({ server: { handlers } }). */
export function eventMapHandlers(getOptions: (request: Request) => CollectorOptions | Promise<CollectorOptions>) {
  const handle = async ({ request }: { request: Request }) => createCollector(await getOptions(request))(request);
  return { POST: handle, OPTIONS: handle };
}
