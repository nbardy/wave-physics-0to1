import { createBrowserTracker } from '@nick/analytics/browser';
import { TanStackAnalytics } from '@nick/analytics/tanstack';

export const analytics = createBrowserTracker({
  siteId: 'eventmap', endpoint: 'http://localhost:8787/collect/eventmap',
  legacyVisitorKey: 'eventmap_anonymous_id',
});
/** Mount once in the existing TanStack root route. */
export function Analytics() { return <TanStackAnalytics tracker={analytics} />; }

// Keep app events/properties:
// analytics.track('calendar_generation_completed', { calendarSlug, citySlug });
// For an app-local collector, see route.ts and supply a dedicated analytics D1 store.
