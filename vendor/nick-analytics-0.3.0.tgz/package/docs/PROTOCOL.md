# Canonical analytics HTTP protocol v1

This is the language boundary between the browser/server SDK and a collector.
TypeScript, Rust, Go, Python, or another implementation can exchange the same JSON.
This protocol describes `/http`'s canonical collector, not the legacy application
payloads used by Magic Genie/EventMap's compatibility transport adapters.

## Event input

POST one JSON object to the configured endpoint, using `Content-Type: application/json`.
The collector's URL and the site's origins belong to the application configuration.
See `examples/protocol/browser-v1.json` and `server-v1.json`.

| Field | Type | Meaning |
| --- | --- | --- |
| `v` | integer, exactly 1 | Wire version |
| `id` | string, 1–255 characters | Stable delivery ID; reuse on retries |
| `siteId` | string, 1–64 ASCII letters/digits/underscore/hyphen | Must match the configured collector site |
| `name` | string matching the schema | `page_view` for page events; app name for custom events |
| `kind` | `page` or `event` | Must agree with the name |
| `timestamp` | nonnegative safe integer | Unix milliseconds, not seconds |
| `path` | nonempty string, at most 2048 characters | Collector normalizes the URL/path and removes unapproved query keys |
| `visitorId`, `sessionId` | optional strings, 1–255 characters | Required for browser collection; can be absent for trusted server events |
| `userId` | optional string, 1–255 characters | Public hints are discarded/replaced by verified application auth |
| `referrer` | optional string, at most 2048 characters | Collector removes credentials, query, and fragment |
| `properties` | JSON object, defaults to `{}` | Application-defined fields; keys at most 128 characters |

Omit absent IDs instead of sending null. `source`, `bot`, and `receivedAt` are
collector-owned metadata and are not accepted as proof from the request body.
Unknown fields are ignored. V1's required fields/meaning remain stable across
package releases; an incompatible wire change requires a different `v`.

Generated JSON Schema files: `schemas/event-v1.schema.json` and
`schemas/browser-v1.schema.json`. Import them via the `/schemas/*` package export.
They derive from the runtime Zod validator using
[Zod's JSON Schema conversion](https://zod.dev/json-schema). Run `npm run build`
then `npm run protocol:generate` after a schema change. Tests check synchronization.
Shape validation alone does not supply request authentication or time policy.

## Collector behavior

- Browser requests require an allowed `Origin`; credentials claiming a server
  source must authenticate. An invalid Authorization header does not fall back
  to anonymous collection. Configure server secrets outside the browser.
- `signup_completed` and `purchase_completed`, plus application-specific confirmed
  events, require trusted server authentication. Assign `source` after auth.
- Public `userId` is removed and may be replaced only by verified request auth.
- Cap the actual streamed body, including requests with no Content-Length.
  The TypeScript default is 16,384 bytes.
- The default time policy permits at most two minutes into the future and one day
  into the past. Hosts with delayed outboxes must explicitly configure that window.
- Normalize paths/referrers before storage. The built-in browser SDK honors
  DNT/GPC and configured exclusions; an alternative host defines any extra policy.
- A successful response follows persisted storage. Deduplicate by
  `(siteId, source, id)` so browser IDs cannot suppress trusted server conversions.

| Response | Meaning |
| --- | --- |
| `204` | Stored, or duplicate already stored; empty body |
| `400` | Invalid event, missing browser IDs, or invalid timestamp |
| `403` | Wrong site/origin/credentials, or a browser attempted a confirmed event |
| `405` | Unsupported method |
| `413` | Body too large |
| `415` | Unsupported content type |
| `429` | Host's configured rate limit rejected the request |
| `503` | Persistence/service failure; success was not acknowledged |

Preflight uses OPTIONS and returns allowed origin/method/content-type headers.
The default TypeScript transport acknowledges only 204. Legacy endpoints can use
`createJsonTransport` with an explicit persistence-acknowledgement predicate; a
successful status alone is insufficient. A new host should use 204 as above.
Retries, if added by the caller, reuse the original ID and use bounded backoff.
An acknowledgement does not create a durable browser queue.

## Rust example

`examples/rust` uses [Serde field naming and optional fields](https://serde.rs/field-attrs.html)
to model the same JSON. Run `npm run check:rust`; both fixture round trips must
pass. Its binary reads a canonical event from stdin and writes it as JSON, without
making a network request. The Serde model is not a replacement for the JSON Schema
or the collector rules above.

A Rust app's existing HTTP client can POST that serialized object and await 204.
To host collection in Rust, use the schema, enforce request policy, set trusted
metadata, await an idempotent database write, and then return 204. There is no
requirement to use the JavaScript backend or a Cloudflare binding.
