# Delivery verification — 2026-09-13

Final library location: `/Users/nicholasbardy/git/lean-analytics`.
Package: `@nick/analytics`, version `0.1.0`, private/local distribution.

| Requested outcome | Evidence |
| --- | --- |
| Extract the key learnings | `docs/LEARNINGS.md` records observed Magic Genie/EventMap behavior and the resulting design decisions. |
| Minimal modular core | `src/core.ts` defines events, context and two ports; browser bundle analysis contains only `core.ts`, `transport.ts`, `browser.ts`, with no external runtime imports. |
| D1 adapters | `src/d1.ts`, `migrations/0001_events.sql`, and direct-store transport in `src/server.ts`. Seven tests run actual SQLite/D1 queries under Miniflare/workerd, not a mocked SQL engine. |
| Next.js and other framework adapters | Separate Next client/server, React, React Router, TanStack and native Fetch entry points. Client directives survive compilation. |
| Usable by all three projects | A packed tarball was installed in three isolated consumer fixtures matching the apps' framework versions. All typechecked and bundled; Next also completed its production build. See `consumer-verification.json`. |
| Browser tracking and confirmed signups | Storage-denied, SSR, privacy-signal, logout/cross-tab identity, expiry, HTTP acknowledgement, trusted conversion and direct-store tests pass. |
| Conversion rates and page flows | Ordered distinct-subject funnels, bounded conversion windows, repeated attempts, duplicate delivery, equal-time repeated steps, bot exclusions, site isolation and page journeys are verified against real D1. |
| Agent access | Optional official-SDK MCP adapter; initialization, discovery, querying and authorization exercised over the MCP HTTP protocol. |
| Separate installable library | Built ESM/type exports and migration files are packaged with `npm pack`; the tarball is about 21 KB before this report, excluding generated Worker runtime declarations. |

Commands run from the final library directory:

- `npm ci --ignore-scripts --offline ...` — clean install from the lockfile.
- `npm run check` — build, strict typecheck, **26 passing tests across 7 files**.
- `npm run check:examples` — all frontend examples and generated Worker binding types pass.
- `node scripts/verify-consumers.mjs` — packed-consumer checks pass for React 18.3.1 / React Router 6.28.0; React 19.0.0 / TanStack Router 1.168.10; React 19.2.4 / Next 16.2.7.
- `npm run worker:dry-run` — Worker bundles successfully with D1, rate limiter and site configuration. The complete server including MCP is 244.89 KiB gzip.
- `npm pack` — all declared JS/type exports and the SQL migration are included.

The standalone browser module measures **3,867 bytes minified / 1,793 bytes gzip**.
The complete Worker size is separate; optional server dependencies do not enter
browser bundles. `tests/package.test.ts` guards that separation and a 4 KiB browser
gzip ceiling.

The stable Miniflare v4 test runtime uses compatibility date 2026-08-06; the Worker
example uses 2026-09-13 and was checked with Wrangler 4.131.1. These are local
verification results. No cloud resource was provisioned, no live traffic was sent,
and no production application was switched to this library. The examples require
their collector URL/origins and private deployment credentials to be configured
when the applications adopt it. Existing legacy data is not automatically migrated.
