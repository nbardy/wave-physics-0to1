# Backend and database adapters

The browser SDK is independent of server framework, programming language, and
database. Its transport sends a versioned JSON event. A collector validates that
event and supplies trusted metadata. Storage and reports are separate capabilities.

```text
Browser SDK ── Transport / JSON v1 ── Collector (TypeScript, Rust, …)
                                         │
                                      EventSink
                                         │
                            D1 / SQLite / PostgreSQL / custom
                                         │
                                       Reports
                                         │
                               HTTP API / dashboard / MCP
```

## Three small interfaces

Import these types from `@nick/analytics/adapters`:

- `Transport.send(event)` delivers an event and rejects an unacknowledged write.
- `EventSink.write(events)` stores events, rejects failure, and deduplicates
  `(siteId, source, id)`. Success means the entire batch is persisted or already
  present. A collector needs only this interface.
- `Reports` supplies `stats`, `pages`, `eventCounts`, `funnel`, `flows`, and `journey`.
  The report API and MCP adapter depend only on it. A read-only host needs no sink.

`AnalyticsStore` combines `EventSink & Reports` for databases implementing both.
There is no adapter registry, global database connection, framework base class, or
required ORM. Construct one adapter and pass it to the collector/report handler.

## Supported storage paths

| Storage | Entry point | State |
| --- | --- | --- |
| Cloudflare D1 | `createD1Store(db)` from `/d1` | Writes and all reports; local workerd tests |
| Existing SQLite/D1 schema | `createSqliteReports(query, { table })` from `/sqlite-reports` | Reports over a canonical compatibility view; app owns writes |
| PostgreSQL canonical schema | `createPostgresStore(query)` from `/postgres` | Atomic batch writes and all reports; Postgres WASM conformance tests |
| Existing PostgreSQL schema | `createPostgresReports(query, { table })` from `/postgres` | Reports over a canonical view; app owns writes |
| Other databases | Implement `EventSink` and/or `Reports` | Extension contract; no claim of a built-in implementation |

SQLite and Postgres share one internal report implementation. Dialect differences
are bound parameter syntax, booleans, and result decoding. Counts and timestamps
are normalized to safe JavaScript integers; JSONB and JSON text both yield JSON
properties. Overflow throws rather than silently changing a metric.

## PostgreSQL example

Apply `migrations/postgres/0001_events.sql` to a dedicated schema/database. For an
existing application table, create a compatibility view exposing the canonical
columns and supply its table name; do not install a conflicting canonical table.
The adapter accepts one query function and does not own connection lifecycle.

```ts
import { createPostgresStore, type PostgresQuery } from '@nick/analytics/postgres';
import { createCollector } from '@nick/analytics/http';

// pool is the host application's node-postgres Pool.
const query: PostgresQuery = async <T>(sql: string, values: (string | number | boolean | null)[]) =>
  (await pool.query(sql, values)).rows as T[];
const analytics = createPostgresStore(query);

const collect = createCollector({
  siteId: 'my-app', allowedOrigins: ['https://my-app.example'], sink: analytics,
  // Also provide authenticateServer for backend-confirmed conversions.
});

await analytics.stats({ siteId: 'my-app', from: startMs, to: endMs });
// createReportApi({ reports: () => analytics, ...existingAdminAuth })
// createAnalyticsMcp({ reports: analytics, ...existingAgentAuth })
```

For postgres.js, the wrapper returns `await sql.unsafe(statement, values)` rows;
for Neon it returns the result of the application's query method. Despite that
driver method's name, values still use bound `$1` parameters. No driver is bundled
by this package. Wrap a transaction's query function to store a business signup
and its analytics event in the same PostgreSQL transaction when they share a DB.

The conformance tests execute the same expected journeys and funnels against D1
and [PGlite's PostgreSQL engine](https://pglite.dev/docs/api). They additionally
exercise string BIGINT decoding, JSONB, compatibility views, and atomic rollback.
The adapter accommodates [node-postgres result decoding](https://node-postgres.com/features/types).
A hosted Postgres service, pool, or Rust SQL driver has not been load-tested here.

## Rust and other backend languages

A Rust service cannot directly import a TypeScript adapter. The shared boundary
is [JSON protocol v1](PROTOCOL.md), with checked-in JSON Schema and fixtures.

1. A Rust app can emit server events over HTTP to a collector hosted anywhere.
   It needs no JavaScript runtime and no analytics-specific database connection.
2. A Rust app can host the collection endpoint itself. The browser SDK points at
   that URL; the server validates the same contract and writes using its own SQLx,
   Diesel, or other database integration.
3. A TypeScript HTTP/MCP service can implement `Reports` by calling a Rust read API.
   A fully native Rust read/MCP service implements the documented report semantics
   itself. The TypeScript report engine is not silently cross-compiled into Rust.

`examples/rust` is a compiled Serde model and JSON round-trip example, tested
against the same fixtures as the TypeScript collector. It is **not** a complete
Rust collector, database driver, or Rust SDK release. Rust ingestion must still
implement the protocol's authentication, validation, and persistence guarantees.

## Current application adoption

Magic Genie and EventMap consume the same 0.3.0 artifact after their existing
D1 acceptance suites pass. The new Postgres and protocol exports do not move
their production databases or remove their specialized dashboards. Their D1
adapters and existing exports remain compatible. Production migration/deployment
is still a separate release step.
