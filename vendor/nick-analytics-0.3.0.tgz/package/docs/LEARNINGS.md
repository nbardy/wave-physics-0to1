# What we extracted

Source inspection: 2026-09-13. The three applications have active unrelated edits;
this repository extracts reusable behavior and supplies integrations without replacing
their current collectors, databases, or production instrumentation.

| Evidence in the existing code | Library decision |
| --- | --- |
| Magic Genie `lib/analytics/client-session.ts` and EventMap `src/utils/analytics/client-session.ts` repeat visitor IDs, session IDs, path filtering and delivery. | One browser adapter, instance-local state, configurable legacy visitor storage key. |
| Both use tab session storage without inactivity expiry. | Session IDs rotate after 30 minutes of inactivity; the visitor survives. Tab-local sessions are intentional. |
| EventMap can throw when reading `window.localStorage` itself, before its storage helper catches errors. | Guard storage property access as well as reads/writes. Retain an in-memory fallback. |
| EventMap's fetch comment records Firefox beacons omitting Origin. Existing delivery helpers don't consistently check the response status. | Fetch with keepalive; 204 means persistence completed. A missing table/DB yields failure, never success-looking 202. |
| EventMap declares acquisition events before every producer is wired. | Application contracts are not proof of collection. Integration tests exercise actual delivery and backend-confirmed signup records. |
| EventMap `usage-report.ts` counts event names independently for its funnels. | D1 queries follow the same visitor/session through ordered steps, within an explicit window. Distinct visitors, duplicate deliveries and repeated attempts are handled separately. |
| Magic Genie `lib/admin/traffic-metrics.ts` already models ordered session journeys. | Preserve event timestamps and ordered event records; expose journeys and adjacent page flows through the same report interface. |
| Magic Genie backend helpers import Next/Clerk; EventMap backend helpers include Postgres/D1 mirroring and calendar fields. | Core imports none of those. Framework handlers accept a store and app-provided auth callback. Product fields live in JSON properties. |
| Browser and edge crawler traffic answer different questions. | Browser pageviews define the visitor denominator. Mark basic detected bots; exclude them from reports. This is not perfect human detection. |
| UTM values are useful attribution data but fragment URL totals. | Canonical paths by default; capture UTM fields separately in properties. Opt into meaningful query keys such as lesson versions. |

The public contract is an event plus two small ports: `Transport.send(event)` and
`EventSink.write(events)`. Reports form a separate read interface. There is no
plugin registry, global singleton, application event catalog, ORM, or auth provider
inside the core. Standard Fetch handlers already fit all three server frameworks,
so Hono is optional rather than an additional required dependency.

The browser/core import graphs have no runtime dependencies. Zod is used on the
server validation path; MCP and frontend frameworks are optional peers exposed
through separate package entry points. MIT projects Counterscale and Umami informed
the comparison; this repository contains no fork of either codebase.

Remaining ownership belongs to the consuming applications: the exact signup
definition, authenticated user lookup, mapping of existing event names, the moment
an event fires, and app-specific privacy/consent policy. Browser `identify()` carries
a hint, not proof; a public collector discards it unless app auth resolves the user.
The signup server must carry the browser visitor/session IDs to join a conversion.

Framework references:
- https://developers.cloudflare.com/d1/worker-api/prepared-statements/
- https://developers.cloudflare.com/workers/best-practices/workers-best-practices/
- https://nextjs.org/docs/app/api-reference/file-conventions/route
- https://github.com/modelcontextprotocol/typescript-sdk
