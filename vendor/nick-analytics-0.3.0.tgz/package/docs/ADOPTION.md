# Application adoption, 2026-09-15

The initial migration used `@nick/analytics` 0.2.0. Both apps now consume the
same 0.3.0 tarball through `file:vendor/nick-analytics-0.3.0.tgz`; the storage
migration and acceptance requirements below still apply. The package remains private and unpublished.
There is one library source repository; app builds do not require a sibling checkout.

## What is shared

| Responsibility | Shared implementation | App responsibility |
| --- | --- | --- |
| Visitor/session identity | Browser tracker, legacy ID import, inactivity expiry, privacy signals | Existing storage-key names and excluded routes |
| Page navigation | Next adapter / React tracking hook | Route vocabulary and marketing dimensions |
| Delivery | JSON transport, timeout, explicit persistence acknowledgement | Existing same-origin endpoint contract |
| Ingestion | Canonical event validation and store transport | Authentication, existing D1/PG writes, application taxonomy |
| Reporting | Stats, named event totals, ordered funnels, page flows, session journeys | Compatibility view over existing rows |
| Read access | Shared Fetch report API | Existing admin authentication |
| Agents | Seven read-only MCP tools | Deployment, credentials, and allowed sites |

The existing specialized admin dashboards remain. New standard reports use the
shared engine at `/api/admin/analytics/shared` in each app. This is not a dashboard
rewrite or a second copy of the event data.

## Acceptance checks

Run `npm run check` in this library and `npm run test:analytics` in each app.
The app tests use their actual migrations, browser adapters, collection handlers,
and reporting adapters against ephemeral Miniflare D1. Only authentication is
stubbed. No production data or external signup/email APIs are involved.

Both app suites assert two blog visitors, one attributed server-confirmed account
signup, and a 0.5 visitor conversion rate. They also check historical rows, stable
legacy identity, duplicate delivery, ordered journeys, page transitions, tenant
isolation, bot/admin exclusion, and rejection of browser-forged signup completion.
EventMap additionally persists a real local newsletter subscription through its
endpoint and checks that duplicate subscriptions do not duplicate conversions.

The library suite covers session expiry/reload, blocked storage, privacy signals,
delivery acknowledgement failures, strict ordered funnels/windows, authenticated
report API bounds, and MCP wire-protocol authorization. Missing server attribution
is tested separately: total signups rise, visitors and attributed conversions do not.

## Migration and release

Apply the app's additive migration before deploying code:

- Magic Genie: `db/d1/migrations/0005_shared_analytics.sql`.
- EventMap: `migrations/d1/0007_shared_analytics.sql`.
- EventMap PostgreSQL/dual-write users: also run
  `migrations/20260915_shared_analytics.sql` against PostgreSQL.

Use the existing Wrangler migration workflow for each app and inspect pending
migrations before applying them. Do **not** apply this library's `0001_events.sql`
over an app database: the legacy table has a different shape. The compatibility
views preserve existing rows and table ownership. Existing code can still write
rows after the additive migration, so reverting application code remains possible.

Production migrations and releases have not been performed as part of this
adoption. Repository working trees also contain unrelated work; deployment must
use a reviewed release that includes the required existing newsletter schema.

Report requests use Unix milliseconds and exclusive end bounds. For example:

```text
GET /api/admin/analytics/shared?report=stats&from=1789430400000&to=1789516800000
GET /api/admin/analytics/shared?report=events&from=1789430400000&to=1789516800000
GET /api/admin/analytics/shared?report=flows&from=1789430400000&to=1789516800000
```

For `report=funnel`, URL-encode a `steps` JSON array such as
`[{"name":"page_view"},{"name":"signup_completed","source":"server"}]`.
The app fixes the site ID and requires its existing admin session. These routes
do not themselves expose MCP; the library's MCP adapter can consume the same
report adapter when an authenticated agent endpoint is deployed.

## Practical limits

- Browser analytics are best effort; blocked scripts/network requests are missing
  traffic. There is no durable browser queue or automated retry policy.
- Session IDs are tab-local. Visitor IDs represent browsers, not verified humans.
- Context-free verified signups count as events. A legacy-schema view attributes
  one only when exactly one authenticated session spans the event timestamp.
  Missing/ambiguous matches stay unattributed; there is no cross-device stitching.
- Clerk signup writes are awaited and fail for provider retry. Newsletter analytics
  remain best effort after successful subscription persistence; an analytics outage
  can omit a conversion. A transactional outbox is separate work if reconciliation
  against every business signup is required.
- EventMap's legacy completion events are conservatively classified as browser
  events. They are not retroactively presented as verified server conversions.
- Existing retention policies still apply. Reports query raw rows; large production
  cohorts need measured query costs before claiming scale or cost guarantees.

To update the package: build and test here, increment the version, run `npm pack`,
copy the same artifact to each app's `vendor/`, update dependency/lockfiles, and run
their adoption tests. Do not edit the unpacked vendor package independently.
