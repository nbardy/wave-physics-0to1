-- Dedicated canonical analytics storage. Use a view/adapter for an existing app schema.
CREATE TABLE IF NOT EXISTS analytics_events (
  seq BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  site_id TEXT NOT NULL,
  event_id TEXT NOT NULL,
  visitor_id TEXT,
  session_id TEXT,
  user_id TEXT,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('page', 'event')),
  timestamp BIGINT NOT NULL,
  received_at BIGINT NOT NULL,
  path TEXT NOT NULL,
  referrer TEXT,
  properties JSONB NOT NULL CHECK (jsonb_typeof(properties) = 'object'),
  source TEXT NOT NULL CHECK (source IN ('browser', 'server')),
  bot BOOLEAN NOT NULL,
  UNIQUE (site_id, source, event_id)
);
CREATE INDEX IF NOT EXISTS analytics_site_time ON analytics_events(site_id, timestamp);
CREATE INDEX IF NOT EXISTS analytics_site_visitor_time ON analytics_events(site_id, visitor_id, timestamp);
CREATE INDEX IF NOT EXISTS analytics_site_session_time ON analytics_events(site_id, session_id, timestamp);
